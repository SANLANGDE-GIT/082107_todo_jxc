package com.atguigu.jxc.entity;

import lombok.Data;
/**
 * 商品单位
 */
@Data
public class Unit {

  private Integer unitId;
  private String unitName;

}
