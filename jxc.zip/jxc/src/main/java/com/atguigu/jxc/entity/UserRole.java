package com.atguigu.jxc.entity;

import lombok.Data;
/**
 * 用户角色
 */
@Data
public class UserRole {

  private Integer userRoleId;
  private Integer roleId;
  private Integer userId;

}
