package com.atguigu.jxc.entity;

import lombok.Data;
/**
 * 角色
 */
@Data
public class Role {

  private Integer roleId;
  private String roleName;
  private String remarks;

}
