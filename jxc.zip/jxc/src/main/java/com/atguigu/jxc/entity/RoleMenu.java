package com.atguigu.jxc.entity;

import lombok.Data;
/**
 * 角色菜单
 */
@Data
public class RoleMenu {

  private Integer roleMenuId;
  private Integer menuId;
  private Integer roleId;

}
